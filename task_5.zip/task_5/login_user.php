<?php
session_start();
require_once "config.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM finaltask WHERE email='$email'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $fetch = mysqli_fetch_array($result);
    }

    $fetch_pass = $fetch['password'];
    $decode_pass = base64_decode($fetch_pass);
    if ($password == $decode_pass) {
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;
        header('location: home.php');
    } else {
        echo "<script>alert('Wrong credentials!')</script>";
    }
}
