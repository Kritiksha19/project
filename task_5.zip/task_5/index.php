<?php require_once "config.php"; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css" href="main.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
</head>

<body>
    <div class="container-fluid wrapper">
        <div class=" title-text">
            <div class="title login">
                Sign Up
            </div>
            <div class="title signup">
                Login
            </div>
        </div>
        <div class="form-container">
            <div class="slide-controls">
                <input type="radio" name="slide" id="login" hidden>
                <input type="radio" name="slide" id="signup" checked hidden>
                <label for="login" class="slide login">Login</label>
                <label for="signup" class="slide signup">Sign Up</label>
                <div class="slider-tab"></div>
            </div>
            <div class="form-inner">
                <form id="sign_up" class="signup" method="POST">
                    <div class="field">
                        <input type="text" placeholder="First Name" id="first" name="first" class="first">
                        <div class="invalid-feedback" style="font-size:13px;margin-left:5px;">First Name is required</div>
                    </div>
                    <div class="field">
                        <input type="text" placeholder="Last Name" id="last" name="last" class="last">
                        <div class="invalid-feedback" style="font-size:13px;margin-left:5px;">Last Name is required</div>
                    </div>
                    <div class="field">
                        <input type="email" placeholder="Email Address" id="email" name="email" class="email">
                        <div class="invalid-feedback" style="font-size:13px;margin-left:5px;">Email is required</div>
                    </div>
                    <div class="field">
                        <input type="text" placeholder="Address" id="address" name="address" class="address">
                        <div class="invalid-feedback" style="font-size:13px;margin-left:5px;">Address is required</div>
                    </div>
                    <div class="beside">
                        <select class="field" name="country" id="country" required>
                            <?php
                            $sql = "SELECT * FROM countries";
                            $result = mysqli_query($conn, $sql); ?>
                            <option selected value="none">Select your Country..</option>
                            <?php while ($row = mysqli_fetch_array($result)) {
                            ?>
                                <option value="<?php echo $row['id']; ?>"><?php echo $row["name"]; ?></option>
                            <?php
                            }
                            ?>

                        </select>
                        <select class="field" name="state" id="state" required>

                        </select>
                        <select class="field" name="city" id="city" required>

                        </select>
                    </div>
                    <br>
                    <div class="form-check form-check-inline">
                        <label class="form-check-label" style="color:black">Gender: </label>
                        <input class="form-check-input" style="margin-left:2%;" type="radio" name="gender" id="gender" value="male" required>
                        <label class="form-check-label">Male</label>
                        <input class="form-check-input" style="margin-left:2%;" type="radio" name="gender" id="gender" value="female">
                        <label class="form-check-label">Female</label>
                    </div>
                    <br>
                    <div class="field">
                        <div class="beside">
                            <label for="profile" class="form-label" style="margin-right:15px; color:black">Profile:</label>
                            <input class="form-control" name="profile" type="file" id="profile" multiple required>
                            <div class="upload-msg"> </div>
                        </div>
                    </div>
                    <div class="field">
                        <input id="password" name="password" type="password" placeholder="Password" class="password">
                        <div class="invalid-feedback" style="font-size:13px;margin-left:5px;">Password is required</div>
                    </div>
                    <div class="field">
                        <input id="cpassword" name="cpassword" type="password" placeholder="Confirm password">
                    </div>
                    <div class="field btn">
                        <div class="btn-layer"></div>
                        <input type="submit" id="sign_up" name="sign_up" value="Sign Up">
                    </div>
                </form>

                <form id="do_login" class="login" method="POST">
                    <div class="field">
                        <input id="login_email" name="email" type="email" placeholder="Email Address" class="email">
                        <div class="invalid-feedback emailError" style="font-size:13px;margin-left:5px;">Email is required</div>
                    </div>
                    <div class="field">
                        <input id="login_password" name="password" type="password" placeholder="Password" class="password">
                        <div class="invalid-feedback passwordError" style="font-size:13px;margin-left:5px;">Password is required</div>
                    </div>
                    <div class="field btn">
                        <div class="btn-layer"></div>
                        <input id="do_login" name="login" type="submit" value="Login">
                    </div>
                    <div class="signup-link">
                        Not a member? <a href="">Sign up now</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        const loginText = document.querySelector(".title-text .login");
        const loginForm = document.querySelector("form.signup");
        const loginBtn = document.querySelector("label.login");
        const signupBtn = document.querySelector("label.signup");
        const signupLink = document.querySelector("form .signup-link a");
        signupBtn.onclick = (() => {
            loginForm.style.marginLeft = "0%";
            loginText.style.marginLeft = "0%";
        });
        loginBtn.onclick = (() => {
            loginForm.style.marginLeft = "-50%";
            loginText.style.marginLeft = "-50%";
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#state').hide();
            $('#city').hide();
            $('#country').on('change', function() {
                var country_id = this.value;
                $.ajax({
                    url: "state.php",
                    type: "POST",
                    data: {
                        country_id: country_id
                    },
                    cache: false,
                    success: function(result) {
                        $('#state').show();

                        $("#state").html(result);
                        $('#city').hide();

                    }
                });
            });
            $('#state').on('change', function() {
                var state_id = this.value;
                $.ajax({
                    url: "city.php",
                    type: "POST",
                    data: {
                        state_id: state_id
                    },
                    cache: false,
                    success: function(result) {
                        $('#city').show();
                        $("#city").html(result);
                    }
                });
            });
            $("#sign_up").on('submit', (function(e) {
                const first = $("#first").val();
                const last = $("#last").val();
                const email = $("#email").val();
                const address = $("#address").val();
                const password = $("#password").val();
                if (first.length == "") {
                    $(".first").addClass("is-invalid");
                } else {
                    $(".first").removeClass("is-invalid");
                }
                if (last.length == "") {
                    $(".last").addClass("is-invalid");
                } else {
                    $(".last").removeClass("is-invalid");
                }
                if (email.length == "") {
                    $(".email").addClass("is-invalid");
                } else {
                    $(".email").removeClass("is-invalid");
                }
                if (address.length == "") {
                    $(".address").addClass("is-invalid");
                } else {
                    $(".address").removeClass("is-invalid");
                }
                if (password.length == "") {
                    $(".password").addClass("is-invalid");
                } else {
                    $(".password").removeClass("is-invalid");
                }
                // if (first.length != "" && last.length != "" && email.length != "" && address.length != "" && password.length != "") {
                if (email.length != "" && password.length != "") {
                    e.preventDefault();
                    $(".upload-msg").text('Loading...');
                    $.ajax({
                        url: "signup_user.php",
                        type: "POST",
                        data: new FormData(this),
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(data) {
                            $(".upload-msg").html(data);
                        }
                    });
                } else {
                    e.preventDefault();
                }
            }));
            $("#do_login").on('submit', (function(e) {
                const login_email = $("#login_email").val();
                const login_password = $("#login_password").val();
                if (login_email.length == "") {
                    $(".email").addClass("is-invalid");
                } else {
                    $(".email").removeClass("is-invalid");
                }

                if (login_password.length == "") {
                    $(".password").addClass("is-invalid");
                } else {
                    $(".password").removeClass("is-invalid");
                }
                if (login_email.length != "" && login_password.length != "") {
                    e.preventDefault();
                    $.ajax({
                        url: "login_user.php",
                        type: "POST",
                        data: new FormData(this),
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(data) {

                            setTimeout(' window.location.href = "home.php"; ', 500);
                        }
                    });
                } else {
                    e.preventDefault();
                }
            }));
        });
    </script>

</body>

</html>