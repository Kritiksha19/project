<?php

session_start();
require_once "config.php";
$email = $_SESSION['email'];

$sql = "SELECT * FROM finaltask WHERE email='$email'";
$result = mysqli_query($conn, $sql);
$fetch = mysqli_fetch_array($result);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="main.css">
    <script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
</head>

<body>
    <div class="wrapper" style="margin-left: 32%;max-height:max-content;">
        <form action="" id="update" name="update" method="POST">
            <h2 class="text-center">Welcome home!</h2>
            <center>
                <img src="<?php echo "uploads/" . $fetch['profile']; ?>" height="150px" width="150px" style="border-radius:50%;">
                <p>Hello there, @<?php echo $fetch['first_name']; ?>, your details are as follows: </p>
                <p style="color:crimson;">*Note: You can change them if you like!*</p>
            </center>
            <div class="form-group">
                <label>First Name:</label>
                <input id="first" name="first" class="form-control" value="<?php echo $fetch['first_name']; ?>">
            </div>
            <div class="form-group">
                <label>Last Name:</label>
                <input id="last" name="last" class="form-control" value="<?php echo $fetch['last_name']; ?>">
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input id="email" name="email" class="form-control" value="<?php echo $fetch['email']; ?>" disabled>
            </div>
            <div class="form-group">
                <label>Address:</label>
                <input id="address" name="address" class="form-control" value="<?php echo $fetch['address']; ?>">
            </div>
            <div class="form-group">
                <label for="country">Country:</label>
                <select class="field" name="country" id="country" required>
                    <?php
                    $sql1 = "SELECT * FROM countries";
                    $result1 = mysqli_query($conn, $sql1); ?>
                    <option selected value="none">Select your Country..</option>
                    <?php while ($row = mysqli_fetch_array($result1)) {
                    ?>
                        <option value="<?php echo $row['id']; ?>" <?php if ($fetch['country'] == $row['name']) {
                                                                        echo 'selected';
                                                                    } ?>><?php echo $row["name"]; ?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="state">State:</label>
                <select class="field" name="state" id="state"> </select>
            </div>
            <div class="form-group">
                <label for="city">City:</label>
                <select class="field" name="city" id="city"> </select>
            </div>
            <div class="form-group">
                <div class="form-check form-check-inline">
                    <label class="form-check-label" style="color:black">Gender: </label>
                    <input class="form-check-input" style="margin-left:2%;" type="radio" name="gender" id="gender" value="male" <?php if ($fetch['gender'] == 'male') {
                                                                                                                                    echo "checked";
                                                                                                                                } ?>>
                    <label class="form-check-label">Male</label>
                    <input class="form-check-input" style="margin-left:2%;" type="radio" name="gender" id="gender" value="female" <?php if ($fetch['gender'] == 'female') {
                                                                                                                                        echo "checked";
                                                                                                                                    } ?>>
                    <label class="form-check-label">Female</label>
                </div>
            </div>
            <div class="form-group">
                <label>Profile:</label>
                <input type="file" id="profile" name="profile" class="form-control"><?php echo $fetch['profile'] ?>
            </div>
            <div class="form-group">
                <input class="form-control button" style="background-color:#9242fa;color:white;" type="submit" name="update" id="update" value="Update Profile">
            </div>
        </form>
        <div class="form-group">
            <button class="form-control button" style="background-color:#9242fa;color:white;" type="submit" name="reset_pass" id="reset_pass" value="Reset Password">Reset Password</button>
        </div>
        <div class="form-group">
            <button class="form-control button" style="background-color:crimson;color:white;" type="submit" name="logout" id="logout" value="Logout">Logout</button>
        </div>

    </div>
    <script>
        $(document).ready(function() {
            // $('#state').hide();
            // $('#city').hide();
            $('#country').on('change', function() {
                var country_id = this.value;
                $.ajax({
                    url: "state.php",
                    type: "POST",
                    data: {
                        country_id: country_id
                    },
                    cache: false,
                    success: function(result) {
                        $('#state').show();

                        $("#state").html(result);
                        $('#city').hide();

                    }
                });
            });
            $('#state').on('change', function() {
                var state_id = this.value;
                $.ajax({
                    url: "city.php",
                    type: "POST",
                    data: {
                        state_id: state_id
                    },
                    cache: false,
                    success: function(result) {
                        $('#city').show();
                        $("#city").html(result);
                    }
                });
            });
            $("#update").on('submit', (function(e) {
                e.preventDefault();
                $(".upload-msg").text('Loading...');
                $.ajax({
                    url: "update.php",
                    type: "POST",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function(data) {
                        $(".upload-msg").html(data);
                        alert('Updated details.');
                        window.location = 'home.php';
                    }
                });
            }));
            $("#logout").click(function() {
                window.location='logout.php';
            });
        });
    </script>

</body>

</html>