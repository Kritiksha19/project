<?php
require_once 'config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first = $_POST['first'];
    $last = $_POST['last'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];
    $profile = $_FILES['profile']['name'];
    $password = $_POST['password'];
    $encpass = base64_encode($password);

    $cid = $_POST['country'];
    $sql1 = "SELECT * FROM countries WHERE id='$cid'";
    $result1 = mysqli_query($conn, $sql1);
    $country = mysqli_fetch_array($result1);
    $cname = $country['name'];

    $sid = $_POST['state'];
    $sql2 = "SELECT * FROM states WHERE id='$sid'";
    $result2 = mysqli_query($conn, $sql2);
    $state = mysqli_fetch_array($result2);
    $sname = $state['name'];

    $ctid = $_POST['city'];
    $sql3 = "SELECT * FROM cities WHERE id='$ctid'";
    $result3 = mysqli_query($conn, $sql3);
    $city = mysqli_fetch_array($result3);
    $ctname = $city['name'];

    $sql = "INSERT INTO `finaltask` (`first_name`, `last_name`, `email`, `address`, `country`, `state`, `city`, `gender`, `profile`, `password`) VALUES ('$first', '$last', '$email', '$address', '$cname', '$sname', '$ctname', '$gender', '$profile', '$encpass');";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "Submited";
    } else {
        echo "Error";
    }
    if (isset($_FILES['profile'])) {
        $filename = $_FILES['profile']['name'];
        $filesize = $_FILES['profile']['size'];
        $filetemp = $_FILES['profile']['tmp_name'];
        $filetype = $_FILES['profile']['type'];

        move_uploaded_file($filetemp, "uploads/" . $filename);
    }
}
